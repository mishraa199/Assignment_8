/*Write a program to draw the following patterns:.accumulate.
ABCDEFGFEDCBA
ABCDEF FEDCBA
ABCDE   EDCBA
ABCD     DCBA
ABC       CBA
AB         BA
A           A
*/
#include <stdio.h>
int main()
{
    int i,j,k;
    for(i=1;i<=7;i++)
    {
        k='A';
        for(j=1;j<=13;j++)
        {
            if((j<=8-i) || (j>=6+i&&j<=13))
            {
                printf("%c",k);
                j<7?k++:k--;
            }

            else
                printf(" ");
            if(i!=1 && j==7)
                    k--;
        }
        printf("\n");
    }
    return 0;
}
